﻿(function($){
jQuery.fn.keyboard = function(options){
	options = $.extend({
		lang:'en'
	}, options);
	
	var make = function(){
		
		var keyboard='\
		<div class="keyboard_close"></div>\
		<div class="keyboard_norm keyboard_type en">\
			<table class="keyboard_row">\
				<tr>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">7</span></span></td>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">8</span></span></td>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">9</span></span></td>\
				</tr>\
			</table>\
			<table class="keyboard_row">\
				<tr>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">4</span></span></td>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">5</span></span></td>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">6</span></span></td>\
				</tr>\
			</table>\
			<table class="keyboard_row">\
				<tr>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">1</span></span></td>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">2</span></span></td>\
					<td><span class="keyboard_key1"><span class="keyboard_key-m1">3</span></span></td>\
				</tr>\
			</table>\
			<table class="keyboard_row">\
				<tr>\
			<td><span class="keyboard_key1"><span class="keyboard_key-m1">0</span></span></td>\
			         <td><span class="keyboard_key1 backspace backspacell"><span class="keyboard_key-m">回退</span></span></td>\
				</tr>\
			</table>\
		</div>\
		';
		
		var $this = $(this);
		var $ico = $('<span class="keyboard_ico"></span>');
		var $keyboard = $('<div class="key_board"></div>');
		
		$keyboard.html(keyboard);
		
		$this.after($ico);
		$this.after($keyboard);
		
		var capsMode = false;
		var shiftMode = false;
		var altMode = false;
		
		$ico.css({
			top: ($this.outerHeight()-$ico.height())/2+$this.offset().top, 
			left: $this.outerWidth()+$this.offset().left-($this.outerHeight()-$ico.height())/2-$ico.width()
		});
		
		$keyboard.find('.keyboard_type').hide();
		$keyboard.find('.keyboard_norm'+'.'+options.lang).show();
		
		$keyboard.find('.b-dropdowna__switcher').html($keyboard.find('.b-menu__item[rel='+options.lang+']').html());
		
		$keyboard.mousedown(function(){
			return false;
		});
		
		$keyboard.on('mousedown', '.keyboard_key1:not(.disabled)', function(){
			if($this.val().length > 20){
				if($(this).hasClass('backspace')){
					$this.val($this.val().substring(0, $this.val().length - 1));
				}
				return
			}
			$(this).addClass('pressed');

			if($(this).hasClass('backspace')){
				$this.val($this.val().substring(0, $this.val().length - 1));
				
			}else if($(this).hasClass('rshift') || $(this).hasClass('lshift')){
				$keyboard.find('.keyboard_type').hide();
				if(capsMode){
					$keyboard.find('.rshift, .lshift, .capslock').removeClass('suppressed');
					capsMode = false;
					shiftMode = false;
					$keyboard.find('.keyboard_norm'+'.'+options.lang).show();
				}else{
					$keyboard.find('.rshift, .lshift').addClass('suppressed');
					capsMode = true;
					shiftMode = true;
					$keyboard.find('.keyboard_key1[rel]').removeClass('suppressed');
					altMode = false;
					$keyboard.find('.keyboard_caps'+'.'+options.lang).show();
				}
				
			}else if($(this).hasClass('capslock')){
				$keyboard.find('.keyboard_type').hide();
				if(capsMode){
					$keyboard.find('.rshift, .lshift, .capslock').removeClass('suppressed');
					capsMode = false;
					shiftMode = false;
					$keyboard.find('.keyboard_norm'+'.'+options.lang).show();
				}else{
					$keyboard.find('.capslock').addClass('suppressed');
					capsMode = true;
					$keyboard.find('.keyboard_key1[rel]').removeClass('suppressed');
					altMode = false;
					$keyboard.find('.keyboard_caps'+'.'+options.lang).show();
				}
				
			}else if($(this).hasClass('enter')){
				$this.closest('form').submit();
			
			}else if($(this).hasClass('marked')){
				$keyboard.find('.keyboard_type').hide();
				if(altMode == $(this).attr('rel')){
					$keyboard.find('.keyboard_key1[rel]').removeClass('suppressed');
					altMode = false;
					$keyboard.find('.keyboard_norm'+'.'+options.lang).show();
				}else{
					$keyboard.find('.keyboard_key1[rel]').removeClass('suppressed');
					$keyboard.find('.keyboard_key1[rel='+$(this).attr('rel')+']').addClass('suppressed');
					altMode = $(this).attr('rel');
					
					$keyboard.find('.capslock').removeClass('suppressed');
					capsMode = false;
					$keyboard.find('.keyboard_type[rel='+$(this).attr('rel')+']').show();
				}

			}else{
				$this.val($this.val()+$(this).find('.keyboard_key-m1').text());
			}
			return false;
		});
		
		$keyboard.on('mouseup', '.keyboard_key1', function(){
			$keyboard.find('.keyboard_key1').removeClass('pressed');
			$this.focus();
			
			if(shiftMode && !$(this).hasClass('rshift') && !$(this).hasClass('lshift') && !altMode){
				$keyboard.find('.keyboard_type').hide();
				$keyboard.find('.rshift, .lshift, .capslock').removeClass('suppressed');
				capsMode = false;
				shiftMode = false;
				$keyboard.find('.keyboard_norm'+'.'+options.lang).show();
			}
		});
		
		$keyboard.on('click', '.b-dropdowna__switcher', function(e){
			e.stopPropagation();
			$keyboard.find('.keyboard_lang-selector').fadeIn(100);
		});
		
		$('body').click(function(){
			$keyboard.find('.keyboard_lang-selector').hide();
			return false;
		});
		
		$ico.click(function(){
			$keyboard.css({left: $this.offset().left+210});
			$keyboard.css({top:$this.offset().top + 80}).fadeToggle(0);
			if($keyboard.offset().left+$keyboard.width() > $(window).width()){
				$keyboard.css({left:'', right:10});
			}
			$ico.toggleClass('active');
		});
		
		$keyboard.find('.keyboard_close').click(function(){
			$keyboard.fadeOut(0);
			$ico.removeClass('active');
		});
		console.log("\u767e\u5ea6\u641c\u7d22\u3010\u7d20\u6750\u5bb6\u56ed\u3011\u4e0b\u8f7d\u66f4\u591aJS\u7279\u6548\u4ee3\u7801");
		$keyboard.on('click', '.b-menu__item', function(){
			options.lang = $(this).attr('rel');
			
			capsMode = false;
			shiftMode = false;
			altMode = false;
			$keyboard.find('.rshift, .lshift, .capslock, .alt').removeClass('suppressed');

			$keyboard.find('.keyboard_type').hide();
			$keyboard.find('.keyboard_norm'+'.'+options.lang).show();
			
			$keyboard.find('.b-dropdowna__switcher').html($(this).html());
			$keyboard.find('.keyboard_lang-selector').hide();
		});
	};
	return this.each(make); 
};
})(jQuery);

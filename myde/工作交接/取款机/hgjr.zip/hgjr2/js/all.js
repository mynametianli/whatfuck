var obj = {};
(function (){
    //http://127.0.0.1:8000
    var root = "http://127.0.0.1:8000/atm/"
    document.oncontextmenu=function()
    {
        return false;
    }
    $(".cardout").click(function(){
        $.ajax({
            type:"get",
            url:"http://127.0.0.1:8000/atm/out_card",
            success:function(res){

                    sessionStorage.removeItem("user");
                    sessionStorage.removeItem("Resu");
                    sessionStorage.removeItem("gcb");
                    sessionStorage.removeItem("cny");
                    sessionStorage.removeItem("cnm");
                    sessionStorage.removeItem("userId");
                    window.location.href = "tuika.html";
            }
        })

    })
    /*if(sessionStorage.getItem('user')){
        $.ajaxSetup({
            headers: {
            /!*     'app-key': 'fb98ab9159f51fd1',
                 'app-secret': '09f7c8cba635f7616bc131b0d8e25947s',*!/
                'user':sessionStorage.getItem('user'),
                'Resu':sessionStorage.getItem('Resu'),
                'withdraw':'1'
            }
        });
    }*/
    obj.index = function(){
	sessionStorage.removeItem("userId");
	/*$("#cardout").click(function(){
              window.location.href = ''

    })*/
      setInterval(function(){
          $.ajax({
              type:"get",
              url:"http://127.0.0.1:8000/atm/check_ma",
              success:function(res){
                  if(JSON.parse(res).status== "200"){
                      $.ajax({
                          type:"get",
                          url:root+"check_card",
                          success:function(res){
                              if(JSON.parse(res).status == "200"){
                                  window.location.href = "content/dukazhong.html"
                              }
                          }

                      })
                  }
                  if(JSON.parse(res).status== "400"){
                      window.location.href = "content/lianxikefu.html";
                  }
              }
          })
      },3000)

 /*       $(".butt").eq(0).click(function(){
            window.location.href = "content/login.html";
        })*/
    }
    obj.login = function(){
	sessionStorage.removeItem("user");
        sessionStorage.removeItem("Resu");
        sessionStorage.removeItem("gcb");
        sessionStorage.removeItem("cny");
        sessionStorage.removeItem("cnm");
        $(".butt1").eq(0).click(function(){
            $(".ban").attr("disabled",true);
            var acid = sessionStorage.getItem("userId");
            var pwd = $("#password").val();
            pwd = $.md5(pwd);
            /*var pwd = $(".keyboard").val();*/
            var data={
                account_id:acid,
                login_pwd:pwd,
                withdraw:"1"
            }
            $.ajax({
                type:"post",
                url:"http://47.89.43.156:8081/account/Login",
                data:JSON.stringify(data),
                success:function(res){
		    $(".ban").attr("disabled",false);
                    if(res.resultCode == "100"){
                    $(".ban").attr("disabled",false);
                    sessionStorage.setItem("user",res.user);
                    sessionStorage.setItem("Resu",res.Resu);
                    window.location.href = "logincg.html"
                    }else{
                        swal({
                            title: "温馨提示",
                            text: "密码错误",
                            type: "warning",
                            showCancelButton: false,
                            confirmButtonColor: '#DD6B55',
                            confirmButtonText: '确定',
                            closeOnConfirm: true
                        })
                    }
                },error:function(){
                    alert("登录失败，请稍后再试");
                    $(".ban").attr("disabled",false);
                    $("#password").val("");
                }
            })
        });
        $(".butt1").eq(1).click(function(){

            $("#password").val("");
        })
    }
/*    obj.loginsuccess = function(){
        $(".butt").eq(0).click(function(){

        })
    }*/
    obj.chaxun = function(){
        $.ajax({
            type:"get",
            url:"http://47.89.43.156:8081/withdraw/balance",
            headers: {
                /*     'app-key': 'fb98ab9159f51fd1',
                 'app-secret': '09f7c8cba635f7616bc131b0d8e25947s',*/
                'user':sessionStorage.getItem('user'),
                'Resu':sessionStorage.getItem('Resu'),
                'withdraw':'1'
            },
            success:function(res){
                sessionStorage.setItem("gcb",res["data"]["gcb"]);
                sessionStorage.setItem("cny",res["data"]["cny"]);
                window.location.href = 'chaxuncg.html';
            },
            error:function(){
                swal({
                        title: "温馨提示",
                        text: "账户查询失败，请稍后再试",
                        type: "warning",
                        showCancelButton: false,
                        confirmButtonColor: '#DD6B55',
                        confirmButtonText: '确定',
                        closeOnConfirm: true
                    },

                    function(){
                        window.location.href = 'logincg.html';
                    }

                )

                /*window.history.back();*/

            }
        })
    }
    obj.search = function(){
        $("#myuser").text(sessionStorage.getItem("userId"));
        $(".padlr").eq(1).text(sessionStorage.getItem("gcb"));
        $(".padlr").eq(2).text(sessionStorage.getItem("cny"));
    }
    obj.qukuan = function(){
        /*$("#searchmoney").click(function(){
            $.ajax({
                type:"get",
                url:"http://192.168.3.25:8081/withdraw/balance",
                success:function(res){
                    sessionStorage.setItem("gcb",res["data"]["gcb"]);
                    sessionStorage.setItem("cny",res["data"]["cny"]);
                    window.location.href = 'chaxuncg.html';
                },
                error:function(XMLHttpRequest, textStatus, errorThrown){
                    alert("查询失败，请稍后再试");
                }
            });
        })*/
        $(".butt").eq(0).click(function(){
	    var _this = $(this);
            $(this).attr("disabled",true);
            withDraw("100",_this);
        })
        $(".butt").eq(1).click(function(){
	    var _this = $(this);	
            $(this).attr("disabled",true);
            withDraw("300",_this);
        });
        $(".butt1").eq(0).click(function(){
	    var _this = $(this);	
            $(this).attr("disabled",true);
            withDraw("200",_this);
        });
        $(".butt1").eq(1).click(function(){
	    var _this = $(this);
            $(this).attr("disabled",true);
            withDraw("500",_this);
        });
    }
    obj.qukuanqita = function(){
        $("#elsedraw").click(function(){
	    var _this = $(this);	
            $(this).attr("disabled",true);
            $(".cardout").attr("disabled",true);
            $("#shade").show();
            var mny = $("#drawmoney").val();
            withDraw(mny,_this);
        })

    }
    obj.zhuanzhang22 = function(){
        $("#yc").hide();
        var cnm = sessionStorage.getItem("cnm");

        $("#djqued").click(function(){
            if(cnm != $(".inp").val()){
                $("#yc").show();
            }else{
                $("#yc").hide();
                window.location.href = 'zhuanzhang4.html'
            }

        });
    }
    obj.zhuanzhang4 = function(){

        $("#yc").hide();
        $("#djqued").click(function(){
	    if(!/^[1-9]/.test($("#forwardmoney").val())){
		swal({
                            title: "温馨提示",
                            text: "转帐金额不能以0开头",
                            type: "warning",
                            showCancelButton: false,
                            confirmButtonColor: '#DD6B55',
                            confirmButtonText: '确定',
                            closeOnConfirm: true
                        }
                    )			
               return
            }
            $(this).attr("disabled",true);
            $(".cardout").attr("disabled",true);
            $("#shade").show();
            var cnm = sessionStorage.getItem("cnm");
            var data = {
                account_transfer:cnm,
                trade_num:$("#forwardmoney").val()
            }
            $.ajax({
                type:"post",
                url:"http://47.89.43.156:8081/withdraw/transfer",
                headers: {
                    /*     'app-key': 'fb98ab9159f51fd1',
                     'app-secret': '09f7c8cba635f7616bc131b0d8e25947s',*/
                    'user':sessionStorage.getItem('user'),
                    'Resu':sessionStorage.getItem('Resu'),
                    'withdraw':'1'
                },
                data:data,
                success:function(res){
                    if(res.status == "success"){
                        window.location.href = "zhuanzhangzhong.html"
                    }else{
                        if(res.code == "999"){
                            $("#yc").show();
                            $("#shade").hide();
                            $("#forwardmoney").val("");
                            $(this).attr("disabled",false);
                            $(".cardout").attr("disabled",false);
                        }else{
			    swal({
                            title: "温馨提示",
                            text: "转账帐号未找到",
                            type: "warning",
                            showCancelButton: false,
                            confirmButtonColor: '#DD6B55',
                            confirmButtonText: '确定',
                            closeOnConfirm: true
                        },
                        function(){
                            window.location.href = 'logincg.html';
                        }
                    )				
			}
                    }
                },
                error:function(){
                    $("#shade").hide();
                    swal({
                            title: "温馨提示",
                            text: "转账失败，请稍后再试",
                            type: "warning",
                            showCancelButton: false,
                            confirmButtonColor: '#DD6B55',
                            confirmButtonText: '确定',
                            closeOnConfirm: true
                        },
                        function(){
                            window.location.href = 'logincg.html';
                        }
                    )
                }
            })
        })

    }
    obj.xiugaimima = function(){
        var isTag = true;
        $("#queding").click(function(){
	    var _this = $(this);	
            $("#shade").show();
            var login_pwd =$.md5($("#oldpwd").val());
            var new_login_pwd1 = $("#newpwd").val();
            var new_login_pwd2 = $("#newpwdr").val();
            var new_login_pwd = $.md5(new_login_pwd2);
            if(!new_login_pwd1 || !new_login_pwd2 || !login_pwd){
                $("#shade").hide();
                swal({
                        title: "温馨提示",
                        text: "请认真核对信息填写是否完整",
                        type: "warning",
                        showCancelButton: false,
                        confirmButtonColor: '#DD6B55',
                        confirmButtonText: '确定',
                        closeOnConfirm: true
                    }
                )

                return
            }
            $(this).attr("disabled",true);
           if(new_login_pwd1 == new_login_pwd2){
                var data = {
                    login_pwd: login_pwd,
                    new_login_pwd: new_login_pwd
                }
                $.ajax({
                    type:"POST",
                    url:"http://47.89.43.156:8081/withdraw/resetpasswd",
                    headers: {
                        /*     'app-key': 'fb98ab9159f51fd1',
                         'app-secret': '09f7c8cba635f7616bc131b0d8e25947s',*/
                        'user':sessionStorage.getItem('user'),
                        'Resu':sessionStorage.getItem('Resu'),
                        'withdraw':'1'
                    },
                    data:data,
                    success:function(res){
                        $("#shade").hide();
                        if(res.status == "success"){
                            window.location.href = "xiugaicg.html"
                        }else{
                           if(res.code == "120"){
                               swal({
                                       title: "温馨提示",
                                       text: "原始密码错误",
                                       type: "warning",
                                       showCancelButton: false,
                                       confirmButtonColor: '#DD6B55',
                                       confirmButtonText: '确定',
                                       closeOnConfirm: true
                                   },
                                   function(){
                                       window.location.href = 'logincg.html';
                                   }
                               )
                            }
                        }
                        $("#queding").attr("disabled",false);
                    },
                    error:function(){
                        $("#shade").hide();
                        $("#queding").attr("disabled",false);
                        swal({
                                title: "温馨提示",
                                text: "密码修改失败，请稍后再试",
                                type: "warning",
                                showCancelButton: false,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: '确定',
                                closeOnConfirm: true
                            },
                            function(){
                                window.location.href = 'logincg.html';
                            }
                        )
                    }
                })
           }else{
               $("#shade").hide();
	       _this.attr("disabled",false);	
               swal({
                       title: "温馨提示",
                       text: "两次密码输入不一致",
                       type: "warning",
                       showCancelButton: false,
                       confirmButtonColor: '#DD6B55',
                       confirmButtonText: '确定',
                       closeOnConfirm: true
                   }
               )
            }
       })
    }
    obj.xiugaicg = function(){
        $("#changepwd").click(function(){
            sessionStorage.removeItem("user");
            sessionStorage.removeItem("Resu");
            sessionStorage.removeItem("gcb");
            sessionStorage.removeItem("cny");
            sessionStorage.removeItem("cnm");
            window.location.href = "login.html";
        })
    }
    obj.getcard = function(){
	sessionStorage.removeItem("card");
        $("#getcard").click(function(){

		if($("#cardcode").val().length == "12"){
            var data =
            {
                code : $("#cardcode").val()
            }
            $.ajax({
                type:"get",
                url:"http://47.89.43.156:8081/withdraw/getcard",
                headers:{
                    'withdraw':'1'
                },
                data:data,
                success:function(res){
                    if(res.status == "success"){
                        sessionStorage.setItem("card",res.account);
                        window.location.href = "zhikazhong .html"
                    }else{
                        window.location.href= 'zhikashibai1.html'
                    }
                }
            })
	}else{
		swal({
                                title: "温馨提示",
                                text: "请输入12位验证码",
                                type: "warning",
                                showCancelButton: false,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: '确定',
                                closeOnConfirm: true
                            })			
	}	

        })

    }
    function withDraw(mny,_this){
        if(!/^[1-9]/.test(mny) || (mny%100) != 0 ){
	  $("#shade").hide();
	  _this.attr("disabled",false);		
          swal({
                                title: "温馨提示",
                                text: "请核对取款金额是否符合规定",
                                type: "warning",
                                showCancelButton: false,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: '确定',
                                closeOnConfirm: true
                            })
		return
        }
	if(mny > 2000){
	     $("#shade").hide();
	     _this.attr("disabled",false);		
             swal({
                                title: "温馨提示",
                                text: "单笔取款不能超过2000",
                                type: "warning",
                                showCancelButton: false,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: '确定',
                                closeOnConfirm: true
                            })
		return;
        }	
        var data = {
            cny:mny
        };
        var dataAtm = parseInt(mny) / 100;
        
        $.ajax({
            type:"post",
            url:"http://47.89.43.156:8081/withdraw/withdraw",
            headers: {
                /*     'app-key': 'fb98ab9159f51fd1',
                 'app-secret': '09f7c8cba635f7616bc131b0d8e25947s',*/
                'user':sessionStorage.getItem('user'),
                'Resu':sessionStorage.getItem('Resu'),
                'withdraw':'1'
            },
            data:data,
            success:function(res){
                if(res.status == "success"){
		     sessionStorage.setItem("dataAtm",dataAtm);
		     window.location.href = 'qukuanzhong.html';
	             
                    
                }else{
                    if(res.code == "999"){
                        swal({
                                title: "温馨提示",
                                text: "账户余额不足",
                                type: "warning",
                                showCancelButton: false,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: '确定',
                                closeOnConfirm: true
                            },
                            function(){
                                window.location.href = 'qukuan.html';
                            }
                        )

                    }
                    if(res.code == "996"){
                        swal({
                                title: "温馨提示",
                                text: "取款超出今日上限",
                                type: "warning",
                                showCancelButton: false,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: '确定',
                                closeOnConfirm: true
                            },
                            function(){
                                window.location.href = 'logincg.html';
                            }
                        )

                    }

                }
            },
            error:function(){
                swal({
                        title: "温馨提示",
                        text: "取款失败，请稍后再试",
                        type: "warning",
                        showCancelButton: false,
                        confirmButtonColor: '#DD6B55',
                        confirmButtonText: '确定',
                        closeOnConfirm: true
                    },
                    function(){
                        window.location.href = 'logincg.html';
                    }
                )
            }
        })
    }
})(obj)


fis.match('*',{
	release:'/hgjr/output/$0'
});
fis.match('*.js', {
  // fis-optimizer-uglify-js 插件进行压缩，已内置
  optimizer: fis.plugin('uglify-js')
});